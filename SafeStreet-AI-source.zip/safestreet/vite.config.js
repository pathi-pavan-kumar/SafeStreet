import {defineConfig} from 'vite';
export default defineConfig({root:'client',envDir:'..',build:{outDir:'../client-build',emptyOutDir:true},server:{allowedHosts:true,proxy:{'/api':'http://127.0.0.1:3001','/uploads':'http://127.0.0.1:3001'}}});

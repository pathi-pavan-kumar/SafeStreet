// Synthetic software fixtures only. No research accuracy or production records involved.
import {test,before,after} from 'node:test';import assert from 'node:assert/strict';import {createServer} from 'node:http';import mongoose from 'mongoose';import request from 'supertest';import fs from 'node:fs/promises';import os from 'node:os';import path from 'node:path';
import {candidate,aggregate,nearbyFilter,distance} from '../server/analysis.js';import {createAIClient,analysisMatchesHealth} from '../server/ai-client.js';import {createApp,Incident} from '../server/app.js';
let dir,app;const uri='mongodb://127.0.0.1:27017/safestreet_reliability_test_'+process.pid;
before(async()=>{dir=await fs.mkdtemp(path.join(os.tmpdir(),'safestreet-reliability-'));await mongoose.connect(uri);app=createApp({uploadDir:dir});});
after(async()=>{if(mongoose.connection.readyState===1){await mongoose.connection.dropDatabase();await mongoose.disconnect();}if(dir)await fs.rm(dir,{recursive:true,force:true});});
const base={title:'tree road blocked',description:'fallen tree across road',latitude:17,longitude:78,occurredAt:'2026-01-01T00:00:00Z',unknownTime:false};
const hash='a55aa55aa55aa55a';
test('duplicate missing fields, malformed times, unknown time and invalid coordinates are conservative',()=>{
 for(const r of [{},{title:'x'},{description:null}]){const c=candidate(r,r);assert.equal(c.match,false);assert.equal(c.hours,null);assert.equal(c.meters,null);assert.equal(c.similarity,r.title?1:0);}
 for(const patch of [{occurredAt:'bad'},{occurredAt:null},{unknownTime:true},{latitude:null},{latitude:91},{longitude:Infinity}])assert.equal(candidate(base,{...base,...patch}).match,false);
 assert.equal(candidate(base,{...base,unknownTime:'false'}).match,true);
 assert.equal(candidate({...base,title:'',description:''},{...base,title:'',description:''}).similarity,0);
});
test('duplicate copied text, unrelated text and different photographs retain separate signals',()=>{
 const a={...base,photo:{perceptualHash:hash}};
 let b={...base,title:'unrelated house',description:'orange clouds',photo:{perceptualHash:hash}};
 let c=candidate(a,b);assert.equal(c.match,true);assert.equal(c.signals.imageMatch,true);assert.equal(c.signals.textMatch,false);
 c=candidate(a,{...b,photo:{perceptualHash:'5aa55aa55aa55aa5'}});assert.equal(c.match,false);
 c=candidate(a,{...base,photo:{perceptualHash:'5aa55aa55aa55aa5'}});assert.equal(c.match,true);assert.equal(c.signals.textMatch,true);assert.equal(c.signals.imageMatch,false);
 for(const h of ['0000000000000000','ffffffffffffffff','bad']){c=candidate({...a,photo:{perceptualHash:h}},{...b,photo:{perceptualHash:h}});assert.equal(c.match,false);assert.equal(c.imageHamming,null);}
});
test('duplicate text/image/time/distance threshold edges are explicit',()=>{
 const common=Array.from({length:7},(_,i)=>'common'+i),aa=Array.from({length:7},(_,i)=>'aaa'+i),bb=Array.from({length:6},(_,i)=>'bbb'+i);
 const a={...base,title:[...common,...aa].join(' '),description:''},b={...base,title:[...common,...bb].join(' '),description:''};
 assert.equal(candidate(a,b).similarity,.35);assert.equal(candidate(a,b).match,true);assert.equal(candidate(a,{...b,title:b.title+' extra'}).match,false);
 const imageA={...base,title:'alpha',description:'',photo:{perceptualHash:hash}},imageB={...base,title:'beta',description:''};
 for(const [mask,want] of [[63n,true],[127n,false]])assert.equal(candidate(imageA,{...imageB,photo:{perceptualHash:(BigInt('0x'+hash)^mask).toString(16).padStart(16,'0')}}).match,want);
 assert.equal(candidate(base,{...base,occurredAt:'2026-01-02T00:00:00Z'}).match,true);assert.equal(candidate(base,{...base,occurredAt:'2026-01-02T00:00:00.001Z'}).match,false);
 const origin={...base,latitude:0,longitude:0};for(const [m,want] of [[499.9,true],[500.1,false]])assert.equal(candidate(origin,{...origin,longitude:m/6371000*180/Math.PI}).match,want);
});
test('spherical distance, bounding filters and polar/dateline grid centers remain valid',()=>{
 assert.ok(distance({latitude:0,longitude:180},{latitude:0,longitude:-180})<0.000001);
 assert.equal(nearbyFilter({}),null);assert.ok(nearbyFilter({latitude:80,longitude:0}).longitude.$gte<-.02);assert.equal(nearbyFilter({latitude:89.999,longitude:0}).longitude,undefined);
 const cells=aggregate([{latitude:90,longitude:180,status:'Verified'},{latitude:90,longitude:-180,status:'Pending review'},{latitude:-90,longitude:0}]);assert.equal(cells.length,2);assert.equal(cells[0].count,2);assert.equal(cells[0].verified,1);assert.ok(cells.every(c=>Math.abs(c.latitude)<=90&&Math.abs(c.longitude)<=180));
});
test('real Mongo duplicate endpoint includes high latitude, date line and polar neighbors, excludes far/unknown time',async()=>{
 for(const [latitude,longitude,nearLat,nearLon] of [[80,0,80,.02],[0,179.999,0,-179.999],[89.999,0,89.999,180]]){
  const doc={...base,category:'Obstruction',photo:{path:'/uploads/test-only-missing.png',mime:'image/png',size:1},latitude,longitude};
  const a=await Incident.create(doc),b=await Incident.create({...doc,latitude:nearLat,longitude:nearLon});
  await Incident.create({...doc,latitude:0,longitude:20});await Incident.create({...doc,occurredAt:null,unknownTime:true});
  const r=await request(app).get('/api/incidents/'+a.id);assert.equal(r.status,200);assert.deepEqual(r.body.analysis.duplicates.map(c=>c.id),[b.id]);
  assert.equal((await Incident.findById(a.id)).status,'Pending review');assert.equal(await Incident.countDocuments(),4);await Incident.deleteMany({});
 }
});
test('query object/array injection, unknown enums, reversed dates and malformed pagination reject consistently',async()=>{
 for(const query of ['status[$ne]=Rejected','category[$ne]=Other','search[]=tree','status=Unknown','category=Crime','page=no','page=-1','page=1.5','limit=101','from=2026-02-01&to=2026-01-01'])for(const endpoint of ['/api/incidents','/api/analysis'])assert.equal((await request(app).get(endpoint+'?'+query)).status,400,endpoint+' '+query);
 assert.equal((await request(app).get('/api/incidents?search=%5B')).status,200);
 const r=await request(app).get('/api/analysis?status=Verified');assert.equal(r.body.total,0);assert.equal(r.body.assessedCount,0);assert.equal(r.body.forecastAvailable,false);assert.match(r.body.recordType,/not confirmed/);
});
const unavailable=task=>({available:false,task,model:null,supportedCategories:[],predictions:[],error:'No input'});
const health={available:true,pipelineVersion:'test-v1',models:{text:{available:true,model:'test-text-v1',supportedCategories:['affected_individuals']},image:{available:false,model:null,supportedCategories:[]}}};
const output=()=>({available:true,schemaVersion:1,pipelineVersion:'test-v1',text:{available:true,task:'disaster_text_humanitarian',model:'test-text-v1',supportedCategories:['affected_individuals'],predictions:[{label:'affected_individuals',score:.6}],limitations:['Software fixture, not trained model evidence.']},image:unavailable('imagenet_objects'),fusion:{available:false},severity:{available:false},imageFingerprint:null,processingTimeMs:1,limitations:['test fixture']});
async function withService(handler,fn){const s=createServer(handler);await new Promise(r=>s.listen(0,'127.0.0.1',r));try{await fn(createAIClient({url:'http://127.0.0.1:'+s.address().port,timeout:100}));}finally{s.closeAllConnections();await new Promise(r=>s.close(r));}}
test('bridge rejects invalid JSON, HTML, oversized chunked output, arrays, bad scores/tasks and false fusion',async()=>{
 const bad=[{available:true},[],{...output(),text:{...output().text,predictions:[{label:'x',score:1.1}]}},{...output(),text:{...output().text,task:'invented'}},{...output(),fusion:{available:true}},{...output(),processingTimeMs:-1}];
 for(const d of bad)await withService((req,res)=>{req.resume();res.setHeader('Content-Type','application/json');res.end(JSON.stringify(d));},async c=>assert.equal((await c.analyze({text:'x'})).available,false));
 for(const [type,body] of [['text/html','<html>not JSON</html>'],['application/json','{'],['application/json','x'.repeat(270000)]])await withService((req,res)=>{req.resume();res.setHeader('Content-Type',type);res.write(body.slice(0,50));res.end(body.slice(50));},async c=>assert.equal((await c.analyze({text:'x'})).available,false));
 await withService((req,res)=>{req.resume();res.writeHead(302,{Location:'http://external.invalid'});res.end();},async c=>assert.equal((await c.health()).available,false));
});
test('output model, supported label and processing version must match health',()=>{
 assert.equal(analysisMatchesHealth(output(),health),true);
 for(const patch of [{pipelineVersion:'new'},{text:{...output().text,model:'wrong'}},{text:{...output().text,predictions:[{label:'Fire',score:.7}]}}])assert.equal(analysisMatchesHealth({...output(),...patch},health),false);
});
test('malformed or mismatched AI output is not persisted and leaves report/status/history unchanged',async()=>{
 const doc=await Incident.create({...base,category:'Other',photo:{path:'/uploads/missing.png',mime:'image/png',size:1}});const before=await Incident.findById(doc.id).lean();
 const bad=createApp({uploadDir:dir,aiClient:{health:async()=>health,analyze:async()=>({...output(),text:{...output().text,predictions:[{label:'Fire',score:.9}]}})}});
 const r=await request(bad).post('/api/incidents/'+doc.id+'/analyze');assert.equal(r.body.available,false);assert.match(r.body.error,/do not match/);assert.deepEqual(await Incident.findById(doc.id).lean(),before);
});
test('assessment cache invalidates processing versions and chooses newest compatible version',async()=>{
 const doc=await Incident.create({...base,category:'Other',photo:{path:'/uploads/missing.png',mime:'image/png',size:1}});let version='test-v1',calls=0;
 const ai={health:async()=>({...health,pipelineVersion:version}),analyze:async()=>{calls++;return {...output(),pipelineVersion:version};}},a=createApp({uploadDir:dir,aiClient:ai});
 let r=await request(a).post('/api/incidents/'+doc.id+'/analyze');assert.equal(r.body.cached,false);version='test-v2';r=await request(a).post('/api/incidents/'+doc.id+'/analyze');assert.equal(r.body.cached,false);assert.equal(calls,2);r=await request(a).post('/api/incidents/'+doc.id+'/analyze');assert.equal(r.body.cached,true);assert.equal(calls,2);assert.equal((await Incident.findById(doc.id)).assessments.length,2);
});

test('concurrent assessment requests share one inference without duplicate history or status changes',async()=>{
 const doc=await Incident.create({...base,category:'Other',photo:{path:'/uploads/missing.png',mime:'image/png',size:1}});let calls=0;
 const a=createApp({uploadDir:dir,aiClient:{health:async()=>health,analyze:async()=>{calls++;await new Promise(r=>setTimeout(r,25));return output();}}});
 const responses=await Promise.all([request(a).post('/api/incidents/'+doc.id+'/analyze'),request(a).post('/api/incidents/'+doc.id+'/analyze')]);assert.ok(responses.every(r=>r.status===200&&r.body.result.available));assert.equal(calls,1);const stored=await Incident.findById(doc.id);assert.equal(stored.assessments.length,1);assert.equal(stored.status,'Pending review');
});

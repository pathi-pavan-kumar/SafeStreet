export const categories=['Accident','Fire','Flood','Obstruction','Environment','Other'];
export const statuses=['Pending review','Verified','Rejected','Possible duplicate'];
export function validCoordinates(p){return !!p&&Number.isFinite(p.latitude)&&Number.isFinite(p.longitude)&&Math.abs(p.latitude)<=90&&Math.abs(p.longitude)<=180;}
export function distance(a,b){if(!validCoordinates(a)||!validCoordinates(b))return null;const r=Math.PI/180,dlat=(b.latitude-a.latitude)*r,dlon=(b.longitude-a.longitude)*r;const h=Math.sin(dlat/2)**2+Math.cos(a.latitude*r)*Math.cos(b.latitude*r)*Math.sin(dlon/2)**2;return 6371000*2*Math.asin(Math.min(1,Math.sqrt(h)));}
// Spherical bounding box encloses the 500 m great-circle cap; exact distance is checked afterwards.
export function nearbyFilter(p,meters=500){
 if(!validCoordinates(p))return null;
 const angle=meters/6371000,deg=180/Math.PI,delta=angle*deg;
 const latitude={$gte:Math.max(-90,p.latitude-delta),$lte:Math.min(90,p.latitude+delta)};
 if(latitude.$gte<=-90||latitude.$lte>=90)return {latitude};
 const dlon=Math.asin(Math.min(1,Math.sin(angle)/Math.cos(p.latitude/deg)))*deg;
 const low=p.longitude-dlon,high=p.longitude+dlon;
 if(low < -180)return {latitude,$or:[{longitude:{$gte:low+360}},{longitude:{$lte:high}}]};
 if(high > 180)return {latitude,$or:[{longitude:{$gte:low}},{longitude:{$lte:high-360}}]};
 return {latitude,longitude:{$gte:low,$lte:high}};
}
function words(r){return new Set([r.title,r.description].filter(v=>typeof v==='string').join(' ').normalize('NFKC').toLowerCase().match(/[\p{L}\p{N}]+/gu)||[]);}
function knownTime(r){if(r.unknownTime===true||r.unknownTime==='true'||!r.occurredAt)return null;const t=new Date(r.occurredAt).getTime();return Number.isFinite(t)?t:null;}
function usableHash(h){if(!/^[a-f0-9]{16}$/.test(h||''))return false;const n=[...BigInt('0x'+h).toString(2)].filter(c=>c==='1').length;return n>=4&&n<=60;}
export function candidate(a,b){
 const x=words(a),y=words(b),union=new Set([...x,...y]).size;
 const similarity=union?[...x].filter(w=>y.has(w)).length/union:0;
 const meters=distance(a,b),at=knownTime(a),bt=knownTime(b);
 const hours=at!==null&&bt!==null?Math.abs(at-bt)/3600000:null;
 const ah=a.photo?.perceptualHash,bh=b.photo?.perceptualHash;
 const imageUsable=usableHash(ah)&&usableHash(bh);
 const imageHamming=imageUsable?[...(BigInt('0x'+ah)^BigInt('0x'+bh)).toString(2)].filter(c=>c==='1').length:null;
 const temporalSpatial=meters!==null&&meters<=500&&hours!==null&&hours<=24;
 const textMatch=similarity>=0.35,imageMatch=imageHamming!==null&&imageHamming<=6;
 return {id:b._id,title:b.title,similarity,meters,hours,imageHamming,match:temporalSpatial&&(textMatch||imageMatch),method:'Rule-based: within 500 m / 24 h, and text Jaccard ≥0.35 OR usable image dHash Hamming ≤6. Near-constant hashes ignored. No automatic merge.',signals:{textMatch,imageMatch,imageUsable,temporalSpatial}};
}
export function aggregate(records){const cells=new Map();for(const r of records){if(!validCoordinates(r))continue;
 // +180 and -180 are the same meridian. Cap north-pole bin to keep cell centers valid.
 const lon=((r.longitude+180)%360+360)%360-180;
 const latBin=Math.min(8999,Math.floor(r.latitude/0.01)),lonBin=Math.floor(lon/0.01),key=latBin+','+lonBin;
 const c=cells.get(key)||{latitude:latBin*0.01+0.005,longitude:lonBin*0.01+0.005,count:0,verified:0};c.count++;if(r.status==='Verified')c.verified++;cells.set(key,c);
}return [...cells.values()];}

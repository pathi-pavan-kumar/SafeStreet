// Bounded loopback-only protocol. Reject malformed output rather than persisting invented success.
const record=v=>v!==null&&typeof v==='object'&&!Array.isArray(v);
const short=(v,max=240)=>typeof v==='string'&&v.length>0&&v.length<=max;
const strings=(v,max=1000)=>Array.isArray(v)&&v.length<=max&&v.every(s=>short(s,300));
function validModality(m){
 if(!record(m)||typeof m.available!=='boolean'||!short(m.task)||!Array.isArray(m.predictions)||!strings(m.supportedCategories))return false;
 if(!m.available)return m.predictions.length===0&&short(m.error,600);
 return short(m.model)&&strings(m.limitations,20)&&m.predictions.length>0&&m.predictions.length<=10&&m.predictions.every(p=>record(p)&&short(p.label,300)&&Number.isFinite(p.score)&&p.score>=0&&p.score<=1&&(p.classIndex===undefined||Number.isInteger(p.classIndex)&&p.classIndex>=0&&p.classIndex<1000));
}
function validHealth(d){return record(d)&&typeof d.available==='boolean'&&record(d.models)&&['text','image'].every(k=>{const m=d.models[k];return record(m)&&typeof m.available==='boolean'&&strings(m.supportedCategories)&&(!m.available||short(m.model)&&m.supportedCategories.length>0);})&&d.available===Object.values(d.models).some(m=>m.available);}
function validAnalysis(d){return record(d)&&typeof d.available==='boolean'&&d.schemaVersion===1&&d.text?.task==='disaster_text_humanitarian'&&d.image?.task==='imagenet_objects'&&validModality(d.text)&&validModality(d.image)&&d.available===(d.text.available||d.image.available)&&record(d.fusion)&&d.fusion.available===false&&record(d.severity)&&d.severity.available===false&&strings(d.limitations,20)&&Number.isFinite(d.processingTimeMs)&&d.processingTimeMs>=0&&(d.imageFingerprint===null||/^[a-f0-9]{16}$/.test(d.imageFingerprint));}
export function analysisMatchesHealth(result,health){
 if(!validAnalysis(result)||!validHealth(health)||(result.pipelineVersion||'legacy-v1')!==(health.pipelineVersion||'legacy-v1'))return false;
 return ['text','image'].every(k=>{const m=result[k],h=health.models[k];return !m.available||(h.available&&m.model===h.model&&m.predictions.every(p=>h.supportedCategories.includes(p.label)&&(k!=='image'||h.supportedCategories[p.classIndex]===p.label)));});
}
export function createAIClient({url=process.env.AI_URL||'',token=process.env.AI_TOKEN||'',timeout=Number(process.env.AI_TIMEOUT_MS)||15000}={}){
 let base;try{base=new URL(url);if(base.protocol!=='http:'||!['127.0.0.1','localhost','[::1]'].includes(base.hostname)||base.username||base.password)base=null;}catch{base=null;}
 const unavailable=error=>({available:false,error,limitations:['Report storage and human review remain available.']});
 async function call(endpoint,body){
  if(!base)return unavailable('AI analysis unavailable — local service not configured');
  const controller=new AbortController(),duration=Number.isFinite(timeout)?Math.max(50,Math.min(timeout,60000)):15000;
  const timer=setTimeout(()=>controller.abort(),duration);
  try{
   const response=await fetch(new URL(endpoint,base),{method:body?'POST':'GET',redirect:'error',headers:{...(body?{'Content-Type':'application/json'}:{}),...(token?{Authorization:'Bearer '+token}:{})},body:body?JSON.stringify(body):undefined,signal:controller.signal});
   if(!response.ok){await response.body?.cancel();return unavailable('AI analysis unavailable — local service returned '+response.status);}
   if(!response.headers.get('content-type')?.toLowerCase().startsWith('application/json')){await response.body?.cancel();return unavailable('AI analysis unavailable — invalid service response');}
   const parts=[];let size=0;
   for await(const part of response.body){size+=part.length;if(size>256*1024){controller.abort();return unavailable('AI analysis unavailable — response exceeds protocol limit');}parts.push(part);}
   let d;try{d=JSON.parse(Buffer.concat(parts).toString('utf8'));}catch{return unavailable('AI analysis unavailable — invalid JSON response');}
   if(record(d)&&d.available===false&&!d.models&&!d.text)return unavailable('AI analysis unavailable — local models or analysis unavailable');
   if(!(endpoint==='/health'?validHealth(d):validAnalysis(d)))return unavailable('AI analysis unavailable — malformed service response');
   return d;
  }catch{return unavailable('AI analysis unavailable — local service unreachable or timed out');}
  finally{clearTimeout(timer);}
 }
 return {health:()=>call('/health'),analyze:body=>call('/analyze',body)};
}

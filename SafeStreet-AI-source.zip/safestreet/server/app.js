import express from 'express';
import mongoose from 'mongoose';
import multer from 'multer';
import crypto from 'node:crypto';
import path from 'node:path';
import fs from 'node:fs/promises';
import {createAIClient,analysisMatchesHealth} from './ai-client.js';
import {categories,statuses,candidate,aggregate,nearbyFilter} from './analysis.js';
mongoose.set('bufferCommands',false);
const schema=new mongoose.Schema({reportId:{type:String,unique:true},title:String,description:String,category:{type:String,enum:categories},latitude:Number,longitude:Number,occurredAt:Date,unknownTime:Boolean,submittedAt:Date,status:{type:String,enum:statuses,default:'Pending review'},source:{type:String,default:'Community report'},photo:{path:String,mime:String,size:Number,perceptualHash:String},assessments:[{assessedAt:Date,inputDigest:String,models:String,result:mongoose.Schema.Types.Mixed}],history:[{status:String,at:Date,note:String}]},{timestamps:true,autoCreate:false,autoIndex:false});
schema.index({submittedAt:-1});schema.index({category:1,status:1});
export const Incident=mongoose.models.Incident||mongoose.model('Incident',schema);
export function createApp({uploadDir=path.resolve('uploads'),moderatorToken=process.env.MODERATOR_TOKEN,aiClient=createAIClient()}={}){
 const inFlight=new Map();
 const app=express();app.disable('x-powered-by');app.use(express.json({limit:'32kb'}));app.use((req,res,next)=>{res.set('X-Content-Type-Options','nosniff');next();});
 app.get('/api/health',(_,res)=>res.status(mongoose.connection.readyState===1?200:503).json({database:mongoose.connection.readyState===1?'connected':'unavailable',ai:'Model status: /api/ai/health. No automated verification or forecasting.'}));
 app.get('/api/ai/health',async(_,res)=>res.json(await aiClient.health()));
 app.use('/api',(_,res,next)=>mongoose.connection.readyState===1?next():res.status(503).json({error:'Database unavailable. Start MongoDB and retry.'}));
 app.use('/uploads',express.static(uploadDir,{dotfiles:'deny',index:false}),(_,res)=>res.status(404).json({error:'Photograph not found'}));
 const upload=multer({storage:multer.memoryStorage(),limits:{fileSize:5*1024*1024,files:1,fields:12},fileFilter:(_,file,cb)=>cb(null,['image/jpeg','image/png'].includes(file.mimetype))});
 function filter(q){
  const fail=message=>{throw Object.assign(new Error(message),{status:400});};
  for(const k of ['search','category','status','from','to','page','limit'])if(q[k]!==undefined&&typeof q[k]!=='string')fail('Filters must be scalar strings');
  if(q.category&&!categories.includes(q.category))fail('Invalid category filter');
  if(q.status&&!statuses.includes(q.status))fail('Invalid status filter');
  for(const k of ['page','limit'])if(q[k]!==undefined&&(!/^[1-9]\d{0,5}$/.test(q[k])||Number(q[k])>(k==='limit'?100:100000)))fail('Invalid pagination');
  const f={};if(q.search)f.$or=['title','description'].map(k=>({[k]:{$regex:q.search.slice(0,120).replace(/[.*+?^${}()|[\]\\]/g,'\\$&'),$options:'i'}}));
  if(q.category)f.category=q.category;if(q.status)f.status=q.status;
  if(q.from||q.to){f.submittedAt={};for(const k of ['from','to'])if(q[k]){const d=new Date(q[k]);if(isNaN(d))fail('Invalid date filter');f.submittedAt[k==='from'?'$gte':'$lte']=d;}if(q.from&&q.to&&new Date(q.from)>new Date(q.to))fail('Date range is reversed');}
  return f;
 }
 app.get('/api/stats',async(req,res,next)=>{try{const rows=await Incident.aggregate([{$group:{_id:'$status',count:{$sum:1}}}]);res.json({total:rows.reduce((n,r)=>n+r.count,0),statuses:Object.fromEntries(rows.map(r=>[r._id,r.count]))});}catch(e){next(e);}});
 app.get('/api/analysis',async(req,res,next)=>{try{const records=await Incident.find(filter(req.query)).select('latitude longitude status history.status assessments.assessedAt').lean();res.json({method:'Historical report counts in 0.01° grid cells; not risk probabilities or forecasts. Includes unverified reports.',cells:aggregate(records),total:records.length,resolutionDegrees:0.01,timeBasis:'submittedAt',window:{from:req.query.from||null,to:req.query.to||null},recordType:'Community submissions, not confirmed incident prevalence',assessedCount:records.filter(r=>r.assessments?.length).length,moderatorReviewedCount:records.filter(r=>r.history?.length>1).length,statusCounts:records.reduce((counts,r)=>{counts[r.status]=(counts[r.status]||0)+1;return counts},{}),ai:'Model status: /api/ai/health. No automated verification or forecasting.',forecastAvailable:false,forecastHorizon:null,forecast:'Unavailable — no validated forecasting dataset or model'});}catch(e){next(e);}});
 app.get('/api/incidents',async(req,res,next)=>{try{const f=filter(req.query),page=Math.max(1,parseInt(req.query.page)||1),limit=Math.min(100,Math.max(1,parseInt(req.query.limit)||5));const [items,total]=await Promise.all([Incident.find(f).select('-assessments').sort({submittedAt:-1}).skip((page-1)*limit).limit(limit).lean(),Incident.countDocuments(f)]);res.json({items,total,page,pages:Math.ceil(total/limit)});}catch(e){next(e);}});
 app.post('/api/incidents',upload.single('photo'),async(req,res,next)=>{let saved;try{const b=req.body,latitude=Number(b.latitude),longitude=Number(b.longitude),unknownTime=b.unknownTime==='true';if(!['true','false'].includes(b.unknownTime)||!['title','description','latitude','longitude'].every(k=>typeof b[k]==='string')||!categories.includes(b.category)||!b.title?.trim()||b.title.length>160||!b.description?.trim()||b.description.length>5000||!b.latitude?.trim()||!b.longitude?.trim()||!Number.isFinite(latitude)||Math.abs(latitude)>90||!Number.isFinite(longitude)||Math.abs(longitude)>180)throw Object.assign(new Error('Valid title, description, category and coordinates are required.'),{status:400});const occurredAt=unknownTime?null:new Date(b.occurredAt);if(!unknownTime&&(!b.occurredAt||isNaN(occurredAt)||occurredAt>new Date()))throw Object.assign(new Error('Occurrence time must be a valid past time, or select unknown time.'),{status:400});const file=req.file;if(!file)throw Object.assign(new Error('A JPG or PNG photograph is required (maximum 5 MB).'),{status:400});const png=file.buffer.subarray(0,8).equals(Buffer.from([137,80,78,71,13,10,26,10])),jpg=file.buffer[0]===255&&file.buffer[1]===216&&file.buffer[2]===255;if(!(png&&file.mimetype==='image/png'||jpg&&file.mimetype==='image/jpeg'))throw Object.assign(new Error('Image signature does not match JPG or PNG.'),{status:400});await fs.mkdir(uploadDir,{recursive:true});const name=crypto.randomUUID()+(png?'.png':'.jpg');saved=path.join(uploadDir,name);await fs.writeFile(saved,file.buffer,{flag:'wx'});const now=new Date();const item=await Incident.create({title:b.title.trim(),description:b.description.trim(),category:b.category,latitude,longitude,unknownTime,occurredAt,submittedAt:now,reportId:'SSR-'+crypto.randomUUID(),photo:{path:'/uploads/'+name,mime:file.mimetype,size:file.size},history:[{status:'Pending review',at:now,note:'Community report submitted; awaiting human review.'}]});res.status(201).json(item);}catch(e){if(saved)await fs.unlink(saved).catch(()=>{});next(e);}});
 app.post('/api/incidents/:id/analyze',async(req,res,next)=>{
  try{
   if(!mongoose.isValidObjectId(req.params.id))return res.status(404).json({error:'Report not found'});
   const item=await Incident.findById(req.params.id);if(!item)return res.status(404).json({error:'Report not found'});
   if(inFlight.has(req.params.id))return res.json(await inFlight.get(req.params.id));
   const job=(async()=>{
    const health=await aiClient.health();if(!health.available)return {...health,available:false};
    let imageBase64;const name=item.photo?.path?.split('/').pop();
    if(name&&/^[a-f0-9-]+\.(png|jpg)$/.test(name)){
     try{const file=path.join(uploadDir,name),stat=await fs.stat(file);if(stat.size<=5*1024*1024)imageBase64=(await fs.readFile(file)).toString('base64');}catch{/* text-only assessment still possible */}
    }
    const text=item.title+' '+item.description,inputDigest=crypto.createHash('sha256').update(text+'|'+(imageBase64||'')).digest('hex');
    const models=JSON.stringify({pipeline:health.pipelineVersion||'legacy-v1',...Object.fromEntries(Object.entries(health.models||{}).sort(([a],[b])=>a.localeCompare(b)).map(([k,v])=>[k,v.model]))});
    const prior=[...(item.assessments||[])].reverse().find(a=>a.inputDigest===inputDigest&&a.models===models);
    if(prior&&(!imageBase64||prior.result?.image?.available||health.models?.image?.available===false))return {...prior.toObject(),cached:true};
    const result=await aiClient.analyze({text,imageBase64});
    if(!result.available)return result;
    if(!analysisMatchesHealth(result,health))return {available:false,error:'AI analysis unavailable — output labels or model version do not match model health'};
    const assessment={assessedAt:new Date(),inputDigest,models,result};
    const update={$push:{assessments:{$each:[assessment],$slice:-3}}};
    if(/^[a-f0-9]{16}$/.test(result.imageFingerprint||''))update.$set={'photo.perceptualHash':result.imageFingerprint};
    await Incident.updateOne({_id:item._id},update);
    return {...assessment,cached:false};
   })();
   inFlight.set(req.params.id,job);try{res.json(await job);}finally{inFlight.delete(req.params.id);}
  }catch(e){next(e);}
 });
 app.get('/api/incidents/:id',async(req,res,next)=>{try{if(!mongoose.isValidObjectId(req.params.id))return res.status(404).json({error:'Report not found'});const item=await Incident.findById(req.params.id).lean();if(!item)return res.status(404).json({error:'Report not found'});const bounds=nearbyFilter(item);const nearby=bounds?await Incident.find({_id:{$ne:item._id},...bounds}).select('title description latitude longitude occurredAt unknownTime photo.perceptualHash').lean():[];res.json({...item,analysis:{ai:'Model status: /api/ai/health. No automated verification or forecasting.',duplicates:nearby.map(b=>candidate(item,b)).filter(c=>c.match).sort((a,b)=>b.similarity-a.similarity).slice(0,10)}});}catch(e){next(e);}});
 app.post('/api/incidents/:id/status',async(req,res,next)=>{try{if(!moderatorToken)return res.status(503).json({error:'Moderator workflow not configured'});if(req.get('Authorization')!=='Bearer '+moderatorToken)return res.status(401).json({error:'Invalid moderator token'});if(!statuses.includes(req.body.status)||typeof req.body.note!=='string'||!req.body.note.trim()||req.body.note.length>1000)return res.status(400).json({error:'Valid status and review note required'});if(!mongoose.isValidObjectId(req.params.id))return res.status(404).json({error:'Report not found'});const item=await Incident.findByIdAndUpdate(req.params.id,{$set:{status:req.body.status},$push:{history:{status:req.body.status,at:new Date(),note:req.body.note.trim()}}},{new:true});if(!item)return res.status(404).json({error:'Report not found'});res.json(item);}catch(e){next(e);}});
 app.use('/api',(_,res)=>res.status(404).json({error:'Endpoint not found'}));
 app.use((err,req,res,next)=>{console.error(err.message);res.status(err instanceof multer.MulterError?400:err.status||500).json({error:err instanceof multer.MulterError?'Upload rejected: '+err.code:err.status?err.message:'Server could not complete the request.'});});return app;
}

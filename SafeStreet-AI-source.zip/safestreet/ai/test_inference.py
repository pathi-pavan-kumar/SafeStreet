import unittest,tempfile,base64,io,sys
from pathlib import Path
import numpy as np
from PIL import Image
from inference import Engine,decode_image,dhash,softmax
from common import normalize,simhash
class InferenceTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):cls.engine=Engine()
    def image(self,color='red'):
        im=Image.new('RGB',(256,256),color);b=io.BytesIO();im.save(b,format='PNG');return base64.b64encode(b.getvalue()).decode()
    def test_artifacts_load(self):
        h=self.engine.health();self.assertTrue(h['models']['text']['available']);self.assertTrue(h['models']['image']['available']);self.assertEqual(len(h['models']['image']['supportedCategories']),1000)
    def test_real_text_model(self):
        r=self.engine.classify_text('The bridge and electricity lines were destroyed by the flood.');self.assertTrue(r['available']);self.assertEqual(len(r['supportedCategories']),8);self.assertIn(r['predictions'][0]['label'],r['supportedCategories']);self.assertTrue(all(0<=p['score']<=1 for p in r['predictions']))
    def test_real_image_model(self):
        r,h=self.engine.classify_image(self.image());self.assertTrue(r['available']);self.assertEqual(len(r['predictions']),3);self.assertEqual(len(h),16);self.assertTrue(all(0<=p['classIndex']<1000 for p in r['predictions']))
    def test_invalid_images(self):
        for im in ['bad base64',base64.b64encode(b'not PNG').decode(),'a'*7_000_001]:
            r,h=self.engine.classify_image(im);self.assertFalse(r['available']);self.assertIsNone(h)
    def test_text_validation(self):
        for text in [None,123,'a'*5201]:
            with self.assertRaises(ValueError):self.engine.classify_text(text)
        self.assertFalse(self.engine.classify_text('')['available']);self.assertFalse(self.engine.classify_text('你好')['available'])
    def test_modalities_and_no_false_fusion(self):
        for request in [{'text':'people need water and shelter'},{'imageBase64':self.image()},{'text':'buildings are damaged','imageBase64':self.image()}]:
            r=self.engine.analyze(request);self.assertTrue(r['available']);self.assertFalse(r['fusion']['available']);self.assertFalse(r['severity']['available'])
    def test_missing_model_fallback(self):
        with tempfile.TemporaryDirectory() as d:
            e=Engine(d);self.assertFalse(e.health()['available']);r=e.analyze({'text':'Bridge damaged','imageBase64':self.image()});self.assertFalse(r['available']);self.assertIsNotNone(r['imageFingerprint'])
    def test_preprocessing_and_fingerprints(self):
        self.assertEqual(normalize('RT @abc: Bridge &amp; ROADS https://example.org/x'),'bridge roads');self.assertEqual(simhash('Road damaged'),simhash('ROAD damaged'));self.assertEqual(dhash(decode_image(self.image())),dhash(decode_image(self.image())))
    def test_softmax(self):self.assertAlmostEqual(float(softmax([1001,1002]).sum()),1)
if __name__=='__main__':unittest.main(verbosity=2)

"""Event-disjoint CrisisMMD TEXT humanitarian experiment. No incident-label remapping."""
import csv,json,time,hashlib,gzip,platform,collections,os
from pathlib import Path
import numpy as np,sklearn,sys,scipy
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import classification_report,confusion_matrix,f1_score,accuracy_score
from sklearn.dummy import DummyClassifier
from common import normalize,simhash
ROOT=Path(__file__).resolve().parents[1];SEED=42
LABELS=['affected_individuals','infrastructure_and_utility_damage','injured_or_dead_people','missing_or_found_people','not_humanitarian','other_relevant_information','rescue_volunteering_or_donation_effort','vehicle_damage']

def run(output_root=None):
    destination=Path(output_root) if output_root else ROOT
    out=destination/'models/crisismmd-text.json.gz';evaluation=destination/'docs/ai-evaluation.json'
    if out.exists() or evaluation.exists():raise RuntimeError('Refusing to overwrite existing research evidence. Use --output-root with an empty temporary experiment directory.')
    out.parent.mkdir(parents=True,exist_ok=True);evaluation.parent.mkdir(parents=True,exist_ok=True)
    started=time.perf_counter();rows=[];filehash={}
    for p in sorted((ROOT/'data/crisismmd').glob('task_humanitarian*.tsv')):
        filehash[p.name]=hashlib.sha256(p.read_bytes()).hexdigest()
        with p.open(encoding='utf-8',newline='') as f:rows.extend(csv.DictReader(f,delimiter='\t'))
    if not rows:raise RuntimeError('Run python ai/prepare.py first')
    # A tweet can have many image rows. Reject conflicting TEXT labels, never use fused/image labels.
    by_id=collections.defaultdict(list)
    for r in rows:by_id[r['tweet_id']].append(r)
    texts=[];conflicts=empty=0
    for tweet,items in sorted(by_id.items()):
        labels={r['label_text'] for r in items};r=items[0];text=normalize(r['tweet_text'])
        if len(labels)!=1 or r['label_text'] not in LABELS:conflicts+=1;continue
        if not text:empty+=1;continue
        texts.append({'id':tweet,'text':text,'label':r['label_text'],'event':r['event_name']})
    # Conservative near-duplicate groups: exact normalized text or bigram SimHash Hamming <=3.
    parent=list(range(len(texts)));buckets=collections.defaultdict(list);exact={}
    def find(i):
        while parent[i]!=i:parent[i]=parent[parent[i]];i=parent[i]
        return i
    def union(a,b):parent[find(a)]=find(b)
    hashes=[]
    for i,r in enumerate(texts):
        h=simhash(r['text']);hashes.append(h)
        if r['text'] in exact:union(i,exact[r['text']])
        exact[r['text']]=i
        candidates=set()
        for band in range(4):candidates.update(buckets[(band,(h>>(16*band))&65535)])
        for j in candidates:
            if (h^hashes[j]).bit_count()<=3:union(i,j)
        for band in range(4):buckets[(band,(h>>(16*band))&65535)].append(i)
    groups=collections.defaultdict(list)
    for i in range(len(texts)):groups[find(i)].append(texts[i])
    # Predeclared event holdouts, NOT a forecast split. Recombine official splits to prevent event overlap.
    def split(r):return 'test' if r['event']=='california_wildfires' else 'validation' if r['event']=='iraq_iran_earthquake' else 'train'
    sets={s:[] for s in ['train','validation','test']};cross=ambiguous=dedup=0
    for group in groups.values():
        parts={split(r) for r in group}
        if len(parts)>1:cross+=len(group);continue
        if len({r['label'] for r in group})>1:ambiguous+=len(group);continue
        representative=min(group,key=lambda r:r['id']);sets[split(representative)].append(representative);dedup+=len(group)-1
    vector=TfidfVectorizer(ngram_range=(1,2),max_features=12000,min_df=2,sublinear_tf=True,strip_accents=None,lowercase=False)
    X={};y={}
    for s,rs in sets.items():
        y[s]=[r['label'] for r in rs]
        X[s]=vector.fit_transform([r['text'] for r in rs]) if s=='train' else vector.transform([r['text'] for r in rs])
    trials=[];best=None
    for c in [0.5,2.0]:
        clf=LogisticRegression(C=c,max_iter=400,random_state=SEED,class_weight='balanced',solver='lbfgs');clf.fit(X['train'],y['train'])
        score=f1_score(y['validation'],clf.predict(X['validation']),labels=LABELS,average='macro',zero_division=0);trials.append({'C':c,'validationMacroF1':score})
        if best is None or score>best[0]:best=(score,clf,c)
    clf=best[1];dummy=DummyClassifier(strategy='most_frequent').fit(X['train'],y['train'])
    def metrics(pred):return {'accuracy':accuracy_score(y['test'],pred),'macroF1':f1_score(y['test'],pred,labels=LABELS,average='macro',zero_division=0),'classificationReport':classification_report(y['test'],pred,labels=LABELS,output_dict=True,zero_division=0),'confusionMatrix':confusion_matrix(y['test'],pred,labels=LABELS).tolist()}
    artifact={'format':1,'task':'disaster_text_humanitarian','classes':clf.classes_.tolist(),'vocabulary':{k:int(v) for k,v in vector.vocabulary_.items()},'idf':vector.idf_.tolist(),'coef':clf.coef_.tolist(),'intercept':clf.intercept_.tolist(),'preprocessing':'common.normalize v1; sklearn word unigrams/bigrams, sublinear tf, L2 normalization','datasetLicense':'CC-BY-NC-SA-4.0'}
    raw=json.dumps(artifact,separators=(',',':'),sort_keys=True).encode();digest=hashlib.sha256(raw).hexdigest();artifact['model']='crisismmd-text-tfidf-logreg-'+digest[:12]
    # Preserve original evidence: all outputs go to the explicitly selected empty destination.
    with out.open('wb') as f:
        with gzip.GzipFile(fileobj=f,mode='wb',mtime=0) as g:g.write(json.dumps(artifact,separators=(',',':'),sort_keys=True).encode())
    from inference import Engine
    engine=Engine(out.parent);roundtrip=[]
    for index,r in enumerate(sets['test'][:20]):
        pred=engine.classify_text(r['text']);reference=clf.predict_proba(X['test'][index])[0]
        roundtrip.extend(abs(p['score']-reference[list(clf.classes_).index(p['label'])]) for p in pred['predictions'])
    if not engine.text or not roundtrip or max(roundtrip)>1e-10:raise RuntimeError('Portable artifact reload/equivalence failed')
    result={'artifactRoundtripMaxAbsoluteError':max(roundtrip), 'seed':SEED,'task':artifact['task'],'model':artifact['model'],'datasetFileHashes':filehash,'audit':{'inputImageRows':len(rows),'uniqueTweetIds':len(by_id),'conflictingTextLabels':conflicts,'emptyText':empty,'crossSplitNearDuplicateRowsRemoved':cross,'ambiguousGroupsRowsRemoved':ambiguous,'duplicateRowsCollapsed':dedup},'split':{s:{'count':len(rs),'events':sorted({r['event'] for r in rs}),'labels':dict(collections.Counter(y[s])),'idsSha256':hashlib.sha256('\n'.join(sorted(r['id'] for r in rs)).encode()).hexdigest()} for s,rs in sets.items()},'selection':trials,'selectedC':best[2],'labels':LABELS,'test':metrics(clf.predict(X['test'])),'majorityBaseline':metrics(dummy.predict(X['test'])),'durationSeconds':time.perf_counter()-started,'hardware':{'platform':platform.platform(),'cpuCount':os.cpu_count()},'versions':{'numpy':np.__version__,'sklearn':sklearn.__version__,'python':sys.version,'scipy':scipy.__version__},'artifactBytes':out.stat().st_size,'artifactSha256':hashlib.sha256(out.read_bytes()).hexdigest(),'limitations':['Event-disjoint evaluation, not forecasting or validation on Hyderabad reports.','Near-duplicate removal uses a defined approximation, not guaranteed semantic identity.','Author/source overlap cannot be excluded: author IDs not available in annotations.','Rare classes and severe domain shift; not a six-category incident classifier.','Softmax scores are not calibrated truth probabilities.']}
    evaluation.write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({k:result[k] for k in ['model','audit','split','selectedC','durationSeconds','artifactBytes']},indent=2));print('Test macro-F1',result['test']['macroF1'],'baseline',result['majorityBaseline']['macroF1'])
if __name__=='__main__':
    import argparse
    p=argparse.ArgumentParser();p.add_argument('--output-root');args=p.parse_args();run(args.output_root)

"""Synthetic software regression fixtures; these are not accuracy measurements."""
import unittest,tempfile,json,gzip,copy,hashlib,base64,io,contextlib
from pathlib import Path
from unittest.mock import patch
import numpy as np
from PIL import Image,ImageOps
from inference import Engine,decode_image,dhash,TEXT_LABELS
import prepare
import train
ROOT=Path(__file__).resolve().parents[1]
class ReliabilityTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        with gzip.open(ROOT/'models/crisismmd-text.json.gz','rt') as f:cls.artifact=json.load(f)
    def test_prepare_reuses_all_valid_files_without_network(self):
        with patch('prepare.download',side_effect=AssertionError('Unexpected download')):
            self.assertEqual(prepare.prepare()['downloadedBytes'],0)
            self.assertEqual(prepare.prepare(offline=True)['reusedFiles'],5)
    def test_offline_missing_or_corrupt_resources_never_download(self):
        with tempfile.TemporaryDirectory() as d:
            root=Path(d);(root/'ai').mkdir();(root/'ai/resources.json').write_bytes((ROOT/'ai/resources.json').read_bytes());(root/'models').mkdir();(root/'models/imagenet-labels.txt').write_text('corrupt')
            with patch('prepare.download',side_effect=AssertionError('Unexpected download')):
                with self.assertRaisesRegex(RuntimeError,'missing/corrupt'):prepare.prepare(root,offline=True)
                self.assertEqual((root/'models/imagenet-labels.txt').read_text(),'corrupt')
    def test_pinned_download_and_atomic_failure_preserve_existing_resource(self):
        class Response:
            def __enter__(self):return self
            def __exit__(self,*args):pass
            def read(self,n):return b'bad'
        with patch('urllib.request.urlopen',return_value=Response()):
            with self.assertRaisesRegex(RuntimeError,'checksum'):prepare.download('https://example.invalid/pinned',3,'0'*64)
        with tempfile.TemporaryDirectory() as d:
            p=Path(d)/'file';p.write_bytes(b'original')
            with patch('prepare.os.replace',side_effect=OSError('test-only failure')):
                with self.assertRaises(OSError):prepare.atomic_write(p,b'replacement')
            self.assertEqual(p.read_bytes(),b'original');self.assertFalse((Path(d)/'file.part').exists())
    def test_training_refuses_to_overwrite_original_evidence(self):
        before=hashlib.sha256((ROOT/'models/crisismmd-text.json.gz').read_bytes()).hexdigest()
        with self.assertRaisesRegex(RuntimeError,'Refusing to overwrite'):train.run()
        self.assertEqual(hashlib.sha256((ROOT/'models/crisismmd-text.json.gz').read_bytes()).hexdigest(),before)
    def test_malformed_parameters_indices_labels_and_metadata_fall_back(self):
        def bad_idf(a):a['idf'][0]=float('nan')
        def bad_coef(a):a['coef'][0].pop()
        def bad_indices(a):a['vocabulary'][next(iter(a['vocabulary']))]=999999
        def bad_intercept(a):a['intercept'].pop()
        def bad_labels(a):a['classes'][0]='Fire'
        def bad_format(a):a['format']=2
        def bad_task(a):a['task']='incident'
        for mutate in [bad_idf,bad_coef,bad_indices,bad_intercept,bad_labels,bad_format,bad_task]:
            a=copy.deepcopy(self.artifact);mutate(a)
            # Recompute ID so dimensional/finite/schema checks, not only hash, must protect loading.
            content={k:v for k,v in a.items() if k!='model'};a['model']='crisismmd-text-tfidf-logreg-'+hashlib.sha256(json.dumps(content,separators=(',',':'),sort_keys=True).encode()).hexdigest()[:12]
            with tempfile.TemporaryDirectory() as d:
                with gzip.open(Path(d)/'crisismmd-text.json.gz','wt') as f:json.dump(a,f)
                self.assertFalse(Engine(d).health()['models']['text']['available'])
        a=copy.deepcopy(self.artifact);a['model']='forged-version'
        with tempfile.TemporaryDirectory() as d:
            with gzip.open(Path(d)/'crisismmd-text.json.gz','wt') as f:json.dump(a,f)
            self.assertFalse(Engine(d).health()['models']['text']['available'])
    def test_decompression_limit(self):
        with tempfile.TemporaryDirectory() as d:
            with gzip.open(Path(d)/'crisismmd-text.json.gz','wb') as f:f.write(b' '*8_000_001)
            self.assertFalse(Engine(d).health()['models']['text']['available'])
    def pattern(self):
        # Structured asymmetric image; a simple flat/gradient fixture cannot establish useful hash behavior.
        y,x=np.indices((96,128));a=((x//16+y//12)%2*160+((x*3+y*5)%64)).astype('uint8')
        return Image.fromarray(np.stack([a,np.roll(a,5,axis=0),np.roll(a,7,axis=1)],axis=-1))
    def encode(self,im,**kwargs):
        b=io.BytesIO();im.save(b,**kwargs);return base64.b64encode(b.getvalue()).decode()
    def test_hash_resize_and_exif_normalization(self):
        im=self.pattern();a=decode_image(self.encode(im,format='PNG'));b=decode_image(self.encode(im.resize((256,192)),format='PNG'))
        self.assertLessEqual((int(dhash(a),16)^int(dhash(b),16)).bit_count(),6)
        exif=Image.Exif();exif[274]=6
        encoded=self.encode(im,format='JPEG',quality=95,exif=exif);decoded=decode_image(encoded)
        raw=Image.open(io.BytesIO(base64.b64decode(encoded)));expected=ImageOps.exif_transpose(raw).convert('RGB')
        self.assertEqual(decoded.size,(96,128));self.assertEqual(dhash(decoded),dhash(expected));self.assertTrue(np.array_equal(np.asarray(decoded),np.asarray(expected)))
    def test_corrupt_truncated_extreme_aspect_and_pixel_limits(self):
        im=self.pattern();encoded=self.encode(im,format='PNG');raw=base64.b64decode(encoded)
        cases=[base64.b64encode(raw[:30]).decode(),base64.b64encode(raw[:50]+b'corruption'+raw[60:]).decode(),self.encode(Image.new('RGB',(33,1)),format='PNG'),self.encode(im,format='GIF')]
        for value in cases:
            with self.assertRaises(ValueError):decode_image(value)
        with patch('inference.Image.MAX_IMAGE_PIXELS',100):
            with self.assertRaises(ValueError):decode_image(encoded)
    def test_unexpected_nonfinite_image_output_is_unavailable(self):
        class Session:
            def get_inputs(self):return [type('Input',(),{'name':'input'})()]
            def run(self,*args):return [np.full((1,1000),np.nan)]
        with tempfile.TemporaryDirectory() as d:
            e=Engine(d);e.session=Session();r,h=e.classify_image(self.encode(self.pattern(),format='PNG'));self.assertFalse(r['available']);self.assertIsNotNone(h)
if __name__=='__main__':unittest.main(verbosity=2)

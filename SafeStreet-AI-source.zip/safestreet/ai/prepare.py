"""Acquire only missing pinned resources. Existing valid files are reused; --offline never downloads."""
import argparse,hashlib,io,json,os,urllib.request,zipfile
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]

def digest(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def valid(path,meta):return path.is_file() and path.stat().st_size==meta['bytes'] and digest(path)==meta['sha256']
def download(url,expected_bytes,sha256):
    request=urllib.request.Request(url,headers={'User-Agent':'SafeStreet-AI-research/1.0 (local educational dataset preparation)'})
    with urllib.request.urlopen(request,timeout=60) as response:data=response.read(expected_bytes+1)
    if len(data)!=expected_bytes or hashlib.sha256(data).hexdigest()!=sha256:raise RuntimeError('Pinned resource size/checksum mismatch: '+url)
    return data

def atomic_write(path,data):
    path.parent.mkdir(parents=True,exist_ok=True);temp=path.with_name(path.name+'.part')
    try:
        temp.write_bytes(data);os.replace(temp,path)
    finally:
        if temp.exists():temp.unlink()

def prepare(root=ROOT,offline=False):
    manifest=json.loads((root/'ai/resources.json').read_text());datasets=manifest['datasetFiles'];model_files={'mobilenetv2-12-int8.onnx':manifest['image_model'],'imagenet-labels.txt':manifest['image_labels']};missing=[name for name,meta in datasets.items() if not valid(root/'data/crisismmd'/name,meta)]
    models={name:meta for name,meta in model_files.items() if not valid(root/'models'/name,meta)}
    if offline and (missing or models):raise RuntimeError('Offline verification failed; missing/corrupt resources: '+', '.join(missing+list(models)))
    downloaded=0
    if missing:
        archive=manifest['dataset'];data=download(archive['url'],archive['bytes'],archive['sha256']);downloaded+=len(data)
        with zipfile.ZipFile(io.BytesIO(data)) as z:
            staged={}
            for name in missing:
                matches=[n for n in z.namelist() if n.endswith('/'+name) or n==name]
                if len(matches)!=1:raise RuntimeError('Ambiguous/missing archive member: '+name)
                meta=datasets[name];info=z.getinfo(matches[0])
                if info.file_size!=meta['bytes']:raise RuntimeError('Annotation size mismatch')
                b=z.read(matches[0])
                if hashlib.sha256(b).hexdigest()!=meta['sha256']:raise RuntimeError('Annotation checksum mismatch')
                staged[name]=b
            for name,b in staged.items():atomic_write(root/'data/crisismmd'/name,b)
    for name,meta in models.items():
        b=download(meta['url'],meta['bytes'],meta['sha256']);downloaded+=len(b);atomic_write(root/'models'/name,b)
    result={'downloadedBytes':downloaded,'reusedFiles':len(datasets)+len(model_files)-len(missing)-len(models),'offline':offline};print(json.dumps(result));return result
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--offline',action='store_true');args=p.parse_args();prepare(offline=args.offline)

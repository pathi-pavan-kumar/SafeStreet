"""CPU-only inference. No downloads/network and no incident label mapping."""
from pathlib import Path
import json,gzip,time,re,math,base64,io,hashlib,warnings
import numpy as np
from PIL import Image,ImageOps
from common import normalize
Image.MAX_IMAGE_PIXELS=20_000_000
ROOT=Path(__file__).resolve().parents[1]
PIPELINE_VERSION='safestreet-local-v2'
TEXT_LABELS=['affected_individuals','infrastructure_and_utility_damage','injured_or_dead_people','missing_or_found_people','not_humanitarian','other_relevant_information','rescue_volunteering_or_donation_effort','vehicle_damage']

def unavailable(task,error='AI analysis unavailable — model not configured'):
    return {'available':False,'task':task,'model':None,'supportedCategories':[],'predictions':[],'error':error}

def softmax(x):
    a=np.asarray(x,dtype=np.float64);e=np.exp(a-np.max(a));return e/e.sum()

def decode_image(encoded):
    if not isinstance(encoded,str) or len(encoded)>7_000_000:raise ValueError('Image input too large or invalid')
    try:
        b=base64.b64decode(encoded,validate=True)
        if not b or len(b)>5*1024*1024:raise ValueError()
        with warnings.catch_warnings():
            warnings.simplefilter('error',Image.DecompressionBombWarning)
            with Image.open(io.BytesIO(b)) as im:
                if im.format not in ('JPEG','PNG'):raise ValueError()
                
                if max(im.size)/min(im.size)>32:raise ValueError()
                im.verify()
            with Image.open(io.BytesIO(b)) as im:
                im.load();return ImageOps.exif_transpose(im).convert('RGB')
    except Exception:raise ValueError('Invalid JPG/PNG or image exceeds safe pixel limit') from None

def dhash(im):
    # Perceptual heuristic, NOT a learned image embedding.
    a=np.asarray(im.convert('L').resize((9,8),Image.Resampling.LANCZOS));bits=(a[:,1:]>a[:,:-1]).flatten()
    return format(sum(int(v)<<i for i,v in enumerate(bits)),'016x')

class Engine:
    def __init__(self,model_dir=None):
        self.directory=Path(model_dir) if model_dir else ROOT/'models';self.text=None;self.session=None;self.labels=[];self.errors={}
        try:
            with gzip.open(self.directory/'crisismmd-text.json.gz','rb') as f:raw=f.read(8_000_001)
            if len(raw)>8_000_000:raise ValueError('Artifact exceeds safe size')
            self.text=json.loads(raw)
            if not isinstance(self.text,dict) or self.text.get('format')!=1 or self.text.get('task')!='disaster_text_humanitarian' or self.text.get('classes')!=TEXT_LABELS:raise ValueError('Unsupported artifact task')
            content={k:v for k,v in self.text.items() if k!='model'}
            expected='crisismmd-text-tfidf-logreg-'+hashlib.sha256(json.dumps(content,separators=(',',':'),sort_keys=True).encode()).hexdigest()[:12]
            if self.text.get('model')!=expected:raise ValueError('Artifact content/version mismatch')
            vocab=self.text['vocabulary'];n=len(vocab)
            if not isinstance(vocab,dict) or not 1<=n<=12000 or not all(isinstance(k,str) and 0<len(k)<=200 and type(v) is int for k,v in vocab.items()) or sorted(vocab.values())!=list(range(n)):raise ValueError('Invalid vocabulary indices')
            self.coef=np.asarray(self.text['coef'],dtype=np.float64);self.idf=np.asarray(self.text['idf'],dtype=np.float64);self.intercept=np.asarray(self.text['intercept'],dtype=np.float64)
            if self.coef.shape!=(8,n) or self.idf.shape!=(n,) or self.intercept.shape!=(8,) or not all(np.isfinite(a).all() for a in [self.coef,self.idf,self.intercept]) or not (self.idf>0).all():raise ValueError('Invalid learned parameter dimensions/values')
        except Exception:self.text=None;self.errors['text']='AI analysis unavailable — text model could not be loaded'
        try:
            import onnxruntime as ort
            opts=ort.SessionOptions();opts.intra_op_num_threads=1;opts.inter_op_num_threads=1
            path=self.directory/'mobilenetv2-12-int8.onnx'
            manifest=json.loads((ROOT/'ai/resources.json').read_text());label_path=self.directory/'imagenet-labels.txt'
            for resource,meta in [(path,manifest['image_model']),(label_path,manifest['image_labels'])]:
                if resource.stat().st_size!=meta['bytes'] or hashlib.sha256(resource.read_bytes()).hexdigest()!=meta['sha256']:raise ValueError('Pinned image resource mismatch')
            self.session=ort.InferenceSession(str(path),sess_options=opts,providers=['CPUExecutionProvider'])
            self.labels=[line.split(' ',1)[1].strip() for line in (self.directory/'imagenet-labels.txt').read_text().splitlines() if line.strip()]
            if len(self.labels)!=1000:raise ValueError()
            self.image_model='mobilenetv2-12-int8-'+hashlib.sha256(path.read_bytes()).hexdigest()[:12]
        except Exception:self.session=None;self.errors['image']='AI analysis unavailable — image model/runtime could not be loaded'
    def health(self):
        return {'available':bool(self.text or self.session),'pipelineVersion':PIPELINE_VERSION,'models':{'text':{'available':bool(self.text),'model':self.text['model'] if self.text else None,'supportedCategories':self.text['classes'] if self.text else []},'image':{'available':self.session is not None,'model':self.image_model if self.session else None,'supportedCategories':self.labels if self.session else []}},'errors':self.errors,'incidentCategoryClassification':False,'severity':False,'forecast':False}
    def classify_text(self,text):
        if not isinstance(text,str) or len(text)>5200:raise ValueError('Text must be a string of at most 5200 characters')
        if not normalize(text):return unavailable('disaster_text_humanitarian','No supported English text supplied')
        if not self.text:return unavailable('disaster_text_humanitarian',self.errors.get('text'))
        start=time.perf_counter();tokens=normalize(text).split();features=tokens+[' '.join(p) for p in zip(tokens,tokens[1:])];vocab=self.text['vocabulary'];counts={}
        for word in features:
            if word in vocab:counts[vocab[word]]=counts.get(vocab[word],0)+1
        if not counts:return unavailable('disaster_text_humanitarian','No terms recognized by the trained English vocabulary')
        x=np.zeros(len(vocab))
        for i,n in counts.items():x[i]=(1+math.log(n))*self.idf[i]
        x/=np.linalg.norm(x);scores=softmax(self.coef@x+self.intercept)
        order=np.argsort(-scores);return {'available':True,'task':'disaster_text_humanitarian','model':self.text['model'],'supportedCategories':self.text['classes'],'predictions':[{'label':self.text['classes'][i],'score':float(scores[i])} for i in order[:3]],'processingTimeMs':(time.perf_counter()-start)*1000,'limitations':['English disaster-tweet humanitarian categories, not SafeStreet incident categories.','Uncalibrated model scores are not probabilities that an incident occurred.','Domain shift and rare-class performance limit usefulness; human review required.']}
    def classify_image(self,encoded):
        if encoded is None:return unavailable('imagenet_objects','No photograph supplied'),None
        start=time.perf_counter()
        try:im=decode_image(encoded)
        except ValueError as e:return unavailable('imagenet_objects',str(e)),None
        fingerprint=dhash(im)
        if self.session is None:return unavailable('imagenet_objects',self.errors.get('image')),fingerprint
        # Official Model Zoo: shorter side 256, center crop 224, RGB [0,1], mean/std, NCHW.
        w,h=im.size;scale=256/min(w,h);im=im.resize((round(w*scale),round(h*scale)),Image.Resampling.BILINEAR);w,h=im.size;im=im.crop(((w-224)//2,(h-224)//2,(w-224)//2+224,(h-224)//2+224))
        x=np.asarray(im,dtype=np.float32)/255;x=(x-np.array([.485,.456,.406],dtype=np.float32))/np.array([.229,.224,.225],dtype=np.float32);x=x.transpose(2,0,1)[None]
        try:
            logits=np.asarray(self.session.run(None,{self.session.get_inputs()[0].name:x})[0])
            if logits.shape!=(1,1000) or not np.isfinite(logits).all():raise ValueError('Invalid image output')
            scores=softmax(logits[0]);order=np.argsort(-scores)[:3]
        except Exception:return unavailable('imagenet_objects','Local image inference failed'),fingerprint
        return {'available':True,'task':'imagenet_objects','model':self.image_model,'supportedCategories':['ImageNet-1K object labels (see /health)'],'predictions':[{'label':self.labels[i],'classIndex':int(i),'score':float(scores[i])} for i in order],'processingTimeMs':(time.perf_counter()-start)*1000,'limitations':['Generic ImageNet objects only; not an accident, fire, flood, damage or emergency classifier.','Scores describe object-label competition, not incident truth or severity.','No task-specific held-out incident-image evaluation was performed.']},fingerprint
    def analyze(self,payload):
        start=time.perf_counter();text=payload.get('text','')
        result_text=self.classify_text(text);result_image,fingerprint=self.classify_image(payload.get('imageBase64'))
        return {'available':result_text['available'] or result_image['available'],'schemaVersion':1,'pipelineVersion':PIPELINE_VERSION,'text':result_text,'image':result_image,'imageFingerprint':fingerprint,'fusion':{'available':False,'method':'side-by-side evidence; no fused prediction','error':'Models have different label spaces; averaging their scores is not justified.'},'severity':{'available':False,'error':'No validated severity model configured'},'processingTimeMs':(time.perf_counter()-start)*1000,'limitations':['Automated supporting evidence only; human status is unchanged.','No six-category incident classifier or future-risk predictor is implemented.']}

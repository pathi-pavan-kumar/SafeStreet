import re,html,unicodedata,hashlib

def normalize(text):
    text=html.unescape(unicodedata.normalize('NFKC',text)).lower()
    text=re.sub(r'https?://\S+|@\w+',' ',text)
    text=re.sub(r'^\s*rt\b',' ',text)
    return ' '.join(re.findall(r'[a-z]{2,}',text))

def simhash(text):
    tokens=normalize(text).split();features=set(zip(tokens,tokens[1:])) if len(tokens)>1 else {(t,) for t in tokens}
    counts=[0]*64
    for feature in features:
        h=int.from_bytes(hashlib.blake2b(' '.join(feature).encode(),digest_size=8).digest(),'big')
        for i in range(64):counts[i]+=1 if (h>>i)&1 else -1
    return sum(1<<i for i,c in enumerate(counts) if c>0)

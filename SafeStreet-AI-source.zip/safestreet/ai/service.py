"""Small loopback-only JSON inference service; one active inference, bounded bodies."""
import argparse,json,os,threading
from http.server import ThreadingHTTPServer,BaseHTTPRequestHandler
from inference import Engine

def main():
    p=argparse.ArgumentParser();p.add_argument('--port',type=int,default=3003);p.add_argument('--model-dir');args=p.parse_args();engine=Engine(args.model_dir);lock=threading.Semaphore(1);token=os.environ.get('AI_TOKEN','')
    class Handler(BaseHTTPRequestHandler):
        def log_message(self,*args):pass
        def reply(self,status,body):
            b=json.dumps(body,allow_nan=False).encode();self.send_response(status);self.send_header('Content-Type','application/json');self.send_header('Content-Length',str(len(b)));self.send_header('Cache-Control','no-store');self.end_headers()
            try:self.wfile.write(b)
            except (BrokenPipeError,ConnectionResetError):pass
        def authorized(self):return not token or self.headers.get('Authorization')=='Bearer '+token
        def do_GET(self):
            if not self.authorized():return self.reply(401,{'error':'Unauthorized'})
            self.reply(200,engine.health()) if self.path=='/health' else self.reply(404,{'error':'Not found'})
        def do_POST(self):
            if not self.authorized():return self.reply(401,{'error':'Unauthorized'})
            if self.path!='/analyze':return self.reply(404,{'error':'Not found'})
            if self.headers.get('Content-Type','').split(';')[0]!='application/json':return self.reply(415,{'error':'JSON required'})
            try:length=int(self.headers.get('Content-Length','0'))
            except ValueError:return self.reply(400,{'error':'Invalid content length'})
            if length<2 or length>7_100_000:return self.reply(413,{'error':'Inference body too large or empty'})
            self.connection.settimeout(10)
            if not lock.acquire(False):return self.reply(429,{'error':'Local inference busy; retry later'})
            try:
                payload=json.loads(self.rfile.read(length))
                if not isinstance(payload,dict):raise ValueError('JSON object required')
                self.reply(200,engine.analyze(payload))
            except (ValueError,TypeError) as e:self.reply(400,{'error':str(e)[:120]})
            except Exception:self.reply(500,{'error':'Local inference failed'})
            finally:lock.release()
    server=ThreadingHTTPServer(('127.0.0.1',args.port),Handler);print('Local AI ready on loopback port '+str(server.server_port),flush=True);server.serve_forever()
if __name__=='__main__':main()

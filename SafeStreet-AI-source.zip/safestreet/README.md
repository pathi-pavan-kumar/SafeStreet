# SafeStreet-AI
**Multimodal Community Incident Verification and Dynamic Geospatial Risk Prediction**

Status: **Partially Complete** — functional local MERN prototype with genuine limited-task text/image AI. Validated six-category incident classification, fused multimodal classification, severity assessment and future-risk prediction are not implemented. No fabricated research results.

## Quick start — Windows / VS Code PowerShell
Install Node.js 20.19+ (or current supported LTS) and MongoDB Community Server 8.x. Open this directory in VS Code.

```powershell
npm ci
Copy-Item .env.example .env
# Edit .env: optionally set MODERATOR_TOKEN to a long random secret.
```
Start MongoDB using the Windows service (administrator PowerShell, if installed as a service):
```powershell
Start-Service MongoDB
```
Alternatively, keep a dedicated terminal open (adjust installed binary path):
```powershell
New-Item -ItemType Directory -Force .runtime\db
& "C:\Program Files\MongoDB\Server\8.0\bin\mongod.exe" --dbpath "$PWD\.runtime\db" --bind_ip 127.0.0.1 --port 27017
```
Production-style local run:
```powershell
npm run build
npm run dev
```
Open **http://localhost:3001**. `dev` starts the backend and serves the built client; rebuild after changing frontend files.
For frontend development, keep the backend running and use a second terminal:
```powershell
npm run client
```
Open http://localhost:5173. Vite proxies `/api` and `/uploads`; no browser-facing localhost API URL is hardcoded.

## Configuration and persistence
`.env.example` documents MONGODB_URI, PORT and optional MODERATOR_TOKEN. Default database: `mongodb://127.0.0.1:27017/safestreet`. Uploaded photos live in project `uploads/`; MongoDB holds their metadata and path, not binary content. Back up both database and uploads together. Never point tests at a user database. No browser-storage or in-memory database substitution exists.
Health: http://localhost:3001/api/health. When MongoDB is absent, health/API return 503. If MongoDB was unavailable at initial startup, restart the backend after starting it. Database files must be kept outside source control.
A fresh database starts empty, with database-derived zero counts. The current workspace contains one user-submitted pending report and its photograph, preserved during testing; do not clear it. There is no seed/demo dataset to clear. Browser/API fixtures are synthetic, isolated, and removed by successful tests.

## Features and layout
- Dashboard, report form, explorer/map and report details follow the four supplied references: navy navigation, blue actions, light cards and split maps. Original references remain in `/home/user/uploads/`, not copied into source.
- Required JPG/PNG up to 5 MiB; preview; category, text, manual map click, coordinate entry, explicit geolocation, known/unknown occurrence time.
- Search, category/status/submission-date filters, pagination, map selection, details, true status history, actual statistics.
- Markers in explorer represent exactly the current page's list. Dashboard map shows the latest five reports. Explorer's optional historical overlay aggregates **all matching records**, not only the displayed page; clearly distinguished in UI.
- Human status changes require configured bearer token and review reason. New reports always remain pending until an explicit action. No automatic merges or verification.
- Details separate occurred/submitted timestamps. Public map link opens OpenStreetMap; no geocoding dependency.

## API
| Method | Path | Purpose |
|---|---|---|
| GET | /api/health | MongoDB/AI availability |
| GET | /api/stats | Actual total and status counts |
| POST | /api/incidents | Multipart form, `photo` field, report fields |
| GET | /api/incidents | `search`, `category`, `status`, `from`, `to`, `page`, `limit` |
| GET | /api/incidents/:id | Details and rule-based duplicate candidates |
| POST | /api/incidents/:id/status | Bearer token; JSON `status`, `note` |
| GET | /api/analysis | Filtered grid counts and explicit AI/forecast limitations |

## Tests
MongoDB must be running at 127.0.0.1:27017:
```powershell
npm test
npm run build
```
The map-repair validation passed 15 API/method tests (the original suite had 13); the current hardened AI-enabled suite passes 34 tests, as described below. All were run in the supplied Linux environment. Current output: `docs/repair-api-results.txt`; original evidence remains in `docs/test-results.txt`. Covers health, upload signature/type/size/missing data, fields, coordinates, timestamps, persistence, retrieval/missing records, literal search, filtering/pagination, statistics, review authorization/history, duplicate thresholds, geographic aggregation, filesystem failure and disconnected-database 503.
Optional real browser test (not a mandatory application dependency):
```powershell
npm install --no-save --package-lock=false playwright
npx playwright install chromium --only-shell
node tests/browser.mjs
```
Uses a process-specific test database and port 3002, starts/stops real backend processes, removes test images and drops only its own database. Current result: `docs/repair-browser-results.txt`; original evidence remains in `docs/browser-results.txt`. The backend restart persistence assertion passed. It does not simulate a machine power loss or restart MongoDB. API fixtures use a tiny PNG, not an incident photograph or research dataset.

## Architecture, research and limitations
See `docs/IMPLEMENTATION.md` for methods, acceptance matrix, provenance, security boundaries and exact unvalidated capabilities. No paid API, cloud inference, tracking or hosted database is required. FOSSGIS tile loading and the external OpenStreetMap link need internet; core reporting and coordinate entry remain local. Do not bulk-download tiles.

## Map repair and provider configuration (17 October 2026)
All five map locations use `SafetyMap` in `client/src.jsx`. Provider settings are centralized in **`client/map-config.js`**; optional `VITE_MAP_*` settings in the project-root `.env` are loaded by Vite (`envDir: '..'`). Rebuild after changing them. Do not put moderator secrets in `VITE_` variables, which are public browser configuration.

Default basemap: **FOSSGIS / OpenStreetMap Germany**, `https://tile.openstreetmap.de/{z}/{x}/{y}.png`, no subdomains or API key. Terms: https://fossgis.de/arbeitsgruppen/osm-server/nutzungsbedingungen/ and style information: https://openstreetmap.de/germanstyle/ . This is a limited, best-effort volunteer service, appropriate only for modest noncommercial web use, not high-volume traffic or native apps without permission. Browser caching follows provider headers; there is no bulk download, offline tile archive, identity spoofing, cache bypass or automatic provider failover.

**Before public deployment, set `VITE_MAP_CONTACT` to your real operator email**, which appears on About; visible operator contact is a provider condition. Do not deploy at scale or commercially without rechecking terms/permission. No contact address was invented for you. Public deployment policy readiness remains conditional on this configuration.

Attribution remains visible even during failure: OSM contributors/ODbL, FOSSGIS tiles/CC BY-SA 2.0, and Report a map issue link. The old OSM Foundation endpoint could return policy-block PNGs (direct probe observed HTTP 200 + X-Blocked); a normal local browser probe succeeded with a Referer. The user's exact preview 403 condition was not independently reproduced. Do not diagnose this as a CSS failure or assume universal provider availability.

On tile errors or an initial 15-second load timeout, the tile layer is removed, avoiding repeated HTTP error imagery. A visible message and explicit same-provider retry remain alongside controls, markers and attribution. Manual coordinates and report submission do not depend on tiles. Arbitrary policy-error PNGs returned with HTTP 200 are not generically detectable by Leaflet; a loaded image alone cannot prove semantic tile correctness. The selected provider was tested with genuine visible road tiles in this environment.

Repair validation: all five pages returned HTTP 200 PNG tiles in Chromium; simulated HTTP 403 and network failures exercised fallback; desktop side-by-side layout checked at 1024/1280/1440px; mobile stacking/visibility/no overflow checked at 390px on all five pages. ResizeObserver invalidates Leaflet size on container changes. API tests, browser upload/persistence/review and production build passed. See `docs/IMPLEMENTATION.md` for the full evidence and limitations.

## Local AI extension — current implementation
The application now supports **real local AI for two limited tasks**, not the six incident categories:
1. **Text:** TF–IDF + multinomial logistic regression trained here on CrisisMMD v2 text-humanitarian labels (eight original labels).
2. **Image:** pretrained **MobileNetV2-12-int8 / ONNX Runtime CPU**, generic ImageNet-1K object labels. Not an incident or severity classifier.

Use **Analyze report locally** on the saved report details page. Submission never waits for inference. A loading state, original labels, model IDs, uncalibrated model scores, limits, assessment timestamp and cached-result state are shown in the existing card. Human status/category remain unchanged. The server retains up to three assessment versions separately from moderation history. Unavailable services/models produce explicit fallback messages; original report/photo remain intact. There is no trained multimodal fused score: the two models have incompatible label spaces.

### Windows setup (Python 3.13 recommended)
Continue using this same project and MongoDB. Reuse an existing compatible Python environment if available; do not create a second one unnecessarily. Otherwise, in VS Code PowerShell:
```powershell
python -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install -r ai/requirements.txt
```
**Existing workspace with valid data/models:** no preparation or training is needed. Verify without network access and start inference:
```powershell
python ai/prepare.py --offline
$env:OPENBLAS_NUM_THREADS="1"
$env:OMP_NUM_THREADS="1"
python ai/service.py
```
**Source-only ZIP / missing resources:** preparation acquires about 6.76 MB on a clean installation; valid existing resources are reused. It never downloads the large image archive. The ZIP retains the original evaluation, so train into an empty temporary experiment directory, not over the original research record:
```powershell
python ai/prepare.py
$env:OPENBLAS_NUM_THREADS="1"
$env:OMP_NUM_THREADS="1"
$experiment = Join-Path $env:TEMP ("safestreet-training-" + [guid]::NewGuid())
python ai/train.py --output-root $experiment
if ($LASTEXITCODE -ne 0) { throw "Training/reload validation failed" }
if (Test-Path "models/crisismmd-text.json.gz") { throw "Existing model preserved; do not overwrite it" }
Move-Item (Join-Path $experiment "models/crisismmd-text.json.gz") "models/crisismmd-text.json.gz"
# Keep $experiment/docs/ai-evaluation.json as this machine's actual training record.
# Compare its metrics/hash with docs/ai-evaluation.json; Windows-native equality is unverified.
python ai/service.py
```
The training command now refuses to overwrite existing model/evaluation paths. Its output is reload-checked before success. On this Linux environment, a temporary repeat reproduced the original artifact exactly; cross-platform numerical identity is not guaranteed. No new permanent experiment/model copy was retained here.

Keep that terminal open. In `.env`, set:
```dotenv
AI_URL=http://127.0.0.1:3003
AI_TOKEN=
AI_TIMEOUT_MS=15000
```
For a shared/untrusted laptop, set a long random **AI_TOKEN** in both `.env` (Node) and `$env:AI_TOKEN` in the Python terminal before starting it. Python deliberately does not load `.env` or external secrets automatically. Set MODERATOR_TOKEN separately for authorized human reviews. Neither secret belongs in a `VITE_` variable.

In another terminal:
```powershell
npm run build
npm run dev
```
Open http://localhost:3001. AI health: http://localhost:3001/api/ai/health. The inference server is loopback-only; all browser requests go through the existing Node backend. Inference never downloads resources or calls cloud AI. If `models/` already contains the supplied artifacts, skip prepare/train for inference; do not duplicate them. Source ZIP excludes datasets/weights; the workspace retains them and the scripts reproduce them.

### Evaluation and tests
Text experiment: five training events / Iraq–Iran validation / California wildfire test, no event overlap. Duplicate tweet IDs and approximate near-duplicate groups handled before fitting. 14,061 training / 496 validation / 1,484 held-out test records. Test macro-F1 **0.4411885**, majority baseline **0.0754118**; accuracy **0.4575472**. These are disaster-text results, **not application accuracy** or verified-incident performance. Rare classes (including only two vehicle-damage test records) and English social-media domain shift are serious limitations. `docs/ai-evaluation.json` includes per-class metrics, confusion matrices, hashes and exact configuration. A second full training run reproduced identical artifact hash and test metrics.

```powershell
# Optional reproduction: use a NEW empty --output-root as above; do not overwrite original evidence.
python -m unittest discover -v -s ai -p "test_*.py"
$env:AI_TEST_ENABLED="1"
# If using a venv, activate it so child test services use that Python.
# Alternatively set AI_PYTHON to the full Python executable path.
npm test
$env:AI_URL="http://127.0.0.1:3003"
node tests/browser.mjs
npm run build
```
Actual results: **34 Node tests passed** with live-AI integration enabled; **18 Python tests passed**; real browser inference/storage/cache and existing five-map/upload/review/restart workflow passed; production build passed. Normal `npm test` without `AI_TEST_ENABLED=1` explicitly skips five live-model cases, allowing core development without Python/models. Current baseline/final evidence is in `docs/reliability-validation.json`; original evidence remains in `docs/ai-*-results.txt`, `docs/ai-python-tests.txt` and `docs/ai-reproducibility.txt`. Default `npm test` passed 29 tests with five live-model tests explicitly skipped.

### Data, licenses and boundaries
- CrisisMMD text annotations: official https://crisisnlp.qcri.org/crisismmd ; QCRI's dataset card declares **CC BY-NC-SA 4.0**: https://huggingface.co/datasets/QCRI/CrisisMMD . Use only for permitted noncommercial research and comply with attribution/share-alike and applicable social-media terms. Trained text artifact is provided for noncommercial research under CC BY-NC-SA 4.0; do not assume commercial permission.
- Citation: Alam, Ofli & Imran, *CrisisMMD: Multimodal Twitter Datasets from Natural Disasters*, ICWSM 2018, https://arxiv.org/abs/1805.00713 ; Ofli, Alam & Imran, *Analysis of Social Media Data using Multimodal Deep Learning for Disaster Response*, ISCRAM 2020, https://arxiv.org/abs/2004.11838 . Preserve these attributions when using derived work.
- Image artifact: ONNX Model Zoo MobileNet, **Apache-2.0**, https://github.com/onnx/models/tree/main/validated/vision/classification/mobilenet . Pretrained on ImageNet; no ImageNet images downloaded or incident-image evaluation claimed. ImageNet training-data rights are distinct from the model artifact's declared license.
- Storage: selected text TSVs **5,886,474 bytes**, trained text model **957,526 bytes**, quantized image model **3,655,033 bytes**, image labels **31,675 bytes**. No 1.8 GB image archive or second ML framework. Inference uses NumPy/Pillow/ONNX Runtime; scikit-learn is needed for training, not the portable JSON inference loader.
- Duplicate image evidence: Pillow-derived 64-bit dHash, not a trained embedding. Within 500m/24h, text Jaccard ≥0.35 **or** image Hamming ≤6 yields a review candidate. Near-constant hashes (fewer than four or more than 60 set bits) are now ignored; other visually similar photos can still collide; no real-world duplicate precision/recall claimed. No automatic merge/delete/verification. Existing reports acquire fingerprints after local analysis.
- Severity labels exist in CrisisMMD's image task, but those images were not acquired and no severity model was trained. NYC 311 was investigated but not downloaded: it is a service-request dataset, not verified emergencies, and does not validate Hyderabad forecasts. No forecasting is implemented.

The detailed current AI architecture, dataset audit, limitations and experiment evidence are appended to `docs/IMPLEMENTATION.md`; earlier build/repair sections there are historical, not claims that AI is still universally unavailable.

## Reliability and dataset review — 17 October 2026
- Preparation verifies pinned files, reuses valid resources, supports `--offline`, validates replacements before atomic installation, and preserves the original manifest. Training refuses to overwrite evidence; `--output-root` supports isolated reproduction.
- Node bounds local AI responses to 256 KiB, validates JSON/schema/tasks/scores, and checks prediction labels, model IDs and pipeline version against health before storage. Text artifact loading validates content identity, vocabulary indices, finite parameter shapes and bounded gzip size. Image resources are pinned before load; nonfinite/unexpected runtime output becomes unavailable.
- Assessment cache keys include pipeline version, select the newest compatible assessment and retain the three-version limit. Change `PIPELINE_VERSION` whenever preprocessing/inference semantics change.
- Duplicate queries use a spherical bounding box with pole/date-line handling, followed by exact 500 m distance and known 24 h time gates. Missing fields, invalid timestamps/coordinates, near-constant hashes and threshold edges have regression tests. Candidate suggestions never merge, delete, or change human status. Hashes are not rotation/crop invariant or real-world evaluated.
- Historical overlay shows submission-time window, AI-assessed/human-reviewed/verified/rejected counts and variable-width 0.01° cells. Assessed is not verified; community density is not incident prevalence. Date-line/pole cell centers stay valid. Scalar filters/enums/pagination/date order are validated server-side.
- Dataset review: `docs/dataset-review.json` records official publisher sources, access/license conflicts, labels and the reviewed AIDER archive size (275,701,096 bytes). Incidents1M is request-gated; AIDER and DisasterVQA do not supply this six-label paired task. No new training data/weights/packages were acquired. No forced labels, new six-category metrics, fusion gain, severity, or forecast claim.
- Reproduction: `docs/research-validation.json` confirms the original artifact/splits/test metrics and baseline match, without overwriting `docs/ai-evaluation.json`. Synthetic regression fixtures are not research accuracy evidence.
- Still unverified: native Windows setup/training, deployment-origin browser behavior, public deployment provider-contact readiness, labelled real-world duplicate precision/recall, and all currently unavailable research tasks. Photo submission checks MIME/signature/size, not full decoding; stricter decoding/pixel/aspect validation occurs on optional analysis.

**Handoff: Partially Complete.** Core application and targeted reliability work are implemented/tested. Six-category incident classification, paired-label fusion, defensible severity and future-risk prediction remain outstanding for the explicit dataset/target/evaluation reasons above. Your existing report/photo and four references remain intact. Source ZIP excludes dependencies, runtime data, uploads, datasets, model weights, build products and secrets.

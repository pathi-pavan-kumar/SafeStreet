// One public, noncommercial web basemap. No automatic provider switching.
// Recheck the operator's terms before changing providers or deploying at scale.
export const mapConfig = Object.freeze({
  name: 'FOSSGIS / OpenStreetMap Germany',
  url: import.meta.env.VITE_MAP_TILE_URL || 'https://tile.openstreetmap.de/{z}/{x}/{y}.png',
  subdomains: import.meta.env.VITE_MAP_SUBDOMAINS || '',
  attribution: import.meta.env.VITE_MAP_ATTRIBUTION ||
    'Data © <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors (<a href="https://opendatacommons.org/licenses/odbl/">ODbL</a>), tiles <a href="https://www.fossgis.de/">FOSSGIS</a> (<a href="https://creativecommons.org/licenses/by-sa/2.0/">CC BY-SA</a>) · <a href="https://www.openstreetmap.org/fixthemap">Report a map issue</a>',
  maxZoom: 18,
  contact: import.meta.env.VITE_MAP_CONTACT || '',
  policy: 'https://fossgis.de/arbeitsgruppen/osm-server/nutzungsbedingungen/'
});
export function validCoordinates(p) {
  return !!p && Number.isFinite(p.latitude) && Number.isFinite(p.longitude) &&
    Math.abs(p.latitude) <= 90 && Math.abs(p.longitude) <= 180;
}
